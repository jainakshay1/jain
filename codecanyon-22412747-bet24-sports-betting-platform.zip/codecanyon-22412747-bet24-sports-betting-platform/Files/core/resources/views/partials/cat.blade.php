<div class="widget-content">
    <div class="widget__title card__header card__header--has-btn">
        <div class="widget_title1">
            <h4>Categories</h4>
        </div>
    </div>
    <div class="widget__content card__content widget_list">
        <div class="side-category-item">
            <a href="http://localhost/bet_ver_09/user-categories/4"><b>Basket Ball</b></a>
        </div>
        <div class="side-category-item">
            <a href="http://localhost/bet_ver_09/user-categories/1"><b>Cricket</b></a>
        </div>
        <div class="side-category-item">
            <a href="http://localhost/bet_ver_09/user-categories/2"><b>Football</b></a>
        </div>
        <div class="side-category-item">
            <a href="http://localhost/bet_ver_09/user-categories/5"><b>Golf</b></a>
        </div>
        <div class="side-category-item">
            <a href="http://localhost/bet_ver_09/user-categories/3"><b>Tenis</b></a>
        </div>
    </div>
</div>