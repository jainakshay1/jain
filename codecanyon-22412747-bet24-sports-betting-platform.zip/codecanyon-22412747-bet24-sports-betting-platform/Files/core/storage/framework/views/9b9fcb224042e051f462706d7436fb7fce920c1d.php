<?php $__env->startSection('content'); ?>

    <div class="bet-section" id="min-height-match-ques">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <aside class="widget card widget--sidebar widget-standings">
                        <?php echo $__env->make('partials.event', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo show_add(1); ?>

                    </aside>
                </div>
                <div class="col-md-6">
                    <div class="panel custom-panel-bg panel-default widget-content panel-content" style="margin-bottom:15px;">

                        <div class="panel-heading">
                            <div class="widget_title1">
                                <h4><?php echo $match->name; ?></h4>
                            </div>
                        </div>

                        <div class="panel-body bet-body">
                            <?php if($match->src != null): ?>
                                <div class="col-md-12">
                                    <div class="videoWrapper">
                                        <?php echo $match->src; ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="col-md-12">
                                <button class="btn btn-block bs-callout  bs-callout-info ">
                                    Match will Expire in <span id="counting<?php echo e($match->id); ?>"></span>
                                </button>
                            </div>
                            <script>
                                // Set the date we're counting down to
                                var countDownDate = new Date("<?php echo e($match->end_date); ?>").getTime();

                                // Update the count down every 1 second
                                var x = setInterval(function () {

                                    // Get todays date and time
                                    var now = new Date().getTime();

                                    // Find the distance between now an the count down date
                                    var distance = countDownDate - now;

                                    // Time calculations for days, hours, minutes and seconds
                                    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                                    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                                    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                                    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                                    // Output the result in an element with id="demo"
                                    document.getElementById("counting<?php echo e($match->id); ?>").innerHTML = days + " Day  " + hours + "h "
                                        + minutes + "m " + seconds + "s ";

                                    // If the count down is over, write some text
                                    if (distance < 0) {
                                        clearInterval(x);
                                        document.getElementById("counting<?php echo e($match->id); ?>").innerHTML = "EXPIRED";
                                    }
                                }, 1000);
                            </script>


                                <?php
                                    $now = \Carbon\Carbon::now();
                                    $q = \App\BetQuestion::where('end_time','<', $now)->get();
                                    foreach ($q as $d) {
                                        $d->status = 2;
                                        $d->save();
                                    }
                                ?>


                            <?php if(count($question) > 0): ?>
                                <div class="col-md-12">
                                    <h6 class="bet-q"><b> Bet Questions :</b></h6>
                                    <br>
                                </div>
                                <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($data->end_time > \Carbon\Carbon::now()): ?>
                                    <?php
                                        $slug =str_slug($data->question);
                                    ?>
                                    <div class="col-md-12">
                                        <a href="<?php echo e(url('option/'.$data->id."/$slug")); ?>"
                                           class="btn btn-block bs-callout bs-callout-warning bet-option  white"><?php echo $data->question; ?></a>
                                    </div>
                                    <?php else: ?>
                                            <div class="col-md-12">
                                        <strong>No question found!!</strong>
                                            </div>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>


                        </div>

                    </div>
                    <br>
                    <?php echo show_add(2); ?>



                </div>

                <aside>
                    <div class="col-md-3">
                        <?php echo show_add(3); ?>


                    </div>
                </aside>

            </div>
        </div>

    </div>


    <script>
        (function ($) {
            $(window).on('resize', function () {
                var bodyHeight = $(window).height();
                $('#min-height-match-ques').css('min-height', parseInt(bodyHeight) - 450);
                console.log(bodyHeight)
            })
            var bodyHeight = $(window).height();
            $('#min-height-match-ques').css('min-height', parseInt(bodyHeight) - 450);
            console.log(bodyHeight)


        }(jQuery))
    </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>