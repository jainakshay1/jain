<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="about-section section-padding-2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="portlet box blue">
                        <div class="portlet-title">
                            <div class="caption">
                                <?php echo e($page_title); ?>

                            </div>
                        </div>

                        <div class="portlet-body">
                            <table class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th scope="col">SL</th>
                                    <th scope="col">Trx</th>
                                    <th scope="col">Details</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Time</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $invests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td  data-label="SL"><?php echo e(++$k); ?></td>
                                        <td  data-label="#Trx"><?php echo e(isset($data->trx) ? $data->trx : '-'); ?></td>
                                        <td  data-label="Details"><?php echo isset($data->gateway->name) ? $data->gateway->name : '-'; ?></td>
                                        <td  data-label="Amount"><?php echo isset($data->amount) ? $data->amount : '-'; ?> <?php echo $basic->currency; ?></td>
                                        <td  data-label="Time"><?php echo isset($data->created_at) ? $data->created_at : '-'; ?> </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo $invests->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About Hostonion End -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>