<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="about-section section-padding-2 section-bg-clr1" id="min-height-trx">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="well">

                        <h6>Get <?php echo e($basic->refcom); ?>% interest per deposit </h6>
                            <div class="input-group reference-url">
                                <input class="btn btn-lg reference-input"  id="myInput"  type="text" value=" <?php echo e(route('refer.register',auth::user()->username)); ?>">
                                <button class="copy btn btn-primary btn-lg" type="button" onclick="myFunction()">Copy</button>
                            </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-md-12">
                    <div class="portlet box blue">
                        <div class="portlet-title">
                            <div class="caption">
                                <?php echo e($page_title); ?>

                            </div>
                        </div>

                        <div class="portlet-body">
                            <table class="table table-striped table-bordered table-hover" >
                                <thead>
                                <tr>
                                    <th scope="col">SL</th>
                                    <th scope="col">Username</th>
                                    <th scope="col">Email</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $invests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="greenbg">
                                        <td data-label="SL"><?php echo e(++$k); ?></td>
                                        <td data-label="Email"><?php echo e(isset($data->username) ? $data->username : 'sdf'); ?> </td>
                                        <td data-label="Email"><?php echo isset($data->email) ? $data->email : 'sdf'; ?> </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo $invests->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About Hostonion End -->



    <script>
        (function($){
            $(window).on('resize',function(){
                var bodyHeight = $(window).height();
                $('#min-height-trx').css('min-height',parseInt(bodyHeight) - 650);
                console.log(bodyHeight)
            })
            var bodyHeight = $(window).height();
            $('#min-height-trx').css('min-height',parseInt(bodyHeight) - 650);
            console.log(bodyHeight)


        }(jQuery));


        function myFunction() {
            /* Get the text field */
            var copyText = document.getElementById("myInput");

            /* Select the text field */
            copyText.select();

            /* Copy the text inside the text field */
            document.execCommand("copy");

        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>