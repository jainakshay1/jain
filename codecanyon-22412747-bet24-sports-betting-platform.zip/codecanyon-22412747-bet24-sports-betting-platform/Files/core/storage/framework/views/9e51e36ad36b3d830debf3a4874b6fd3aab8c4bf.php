<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="about-section section-padding-2 section-bg-clr1" id="min-height-activity">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="portlet box blue">
                        <div class="portlet-title">
                            <div class="caption">
                                <?php echo e($page_title); ?>

                            </div>

                        </div>

                        <div class="portlet-body">
                            <table class="table table-striped table-bordered table-hover" id="">
                                <thead>
                                <tr>
                                    <th scope="col">SL</th>
                                    <th scope="col">Match</th>
                                    <th scope="col">Question</th>
                                    <th scope="col">Threat</th>
                                    <th scope="col"> Bet Amount</th>
                                    <th scope="col"> Return Amount</th>
                                    <th scope="col">Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $invests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td  data-label="SL"><?php echo e(++$k); ?></td>
                                        <td  data-label="Match">
                                            <?php
                                                $slug =$data->match->slug
                                            ?>
                                            <a href="<?php echo e(url('match/'.$data->match->id.'/'.str_slug($data->match->name))); ?>">
                                            <?php echo e(isset($data->match->name) ? $data->match->name : 'N/A'); ?>

                                            </a>
                                        </td>
                                        <?php
                                            $question = App\BetQuestion::whereId($data->betoption->question_id)->first();
                                        ?>
                                        <td  data-label="Question"><?php echo isset($question->question) ? $question->question : 'N/A'; ?></td>
                                        <td  data-label="Threat"><?php echo isset($data->betoption->option_name) ? $data->betoption->option_name : 'N/A'; ?> </td>
                                        <td  data-label="Bet Amount"><?php echo isset($data->invest_amount) ? $data->invest_amount : 'N/A'; ?> <?php echo $basic->currency; ?></td>
                                        <td  data-label="Return Amount"><?php echo isset($data->	return_amount) ? $data->	return_amount : 'N/A'; ?> <?php echo $basic->currency; ?></td>

                                        <td  data-label="Status">
                                            <?php if($data->status  == 1): ?>
                                            <b class="btn btn-sm btn-success">Win</b>
                                                <?php elseif($data->status  == -1): ?>
                                                <b class="btn btn-sm btn-danger">Lose</b>
                                            <?php elseif($data->status  == 0): ?>
                                                <b class="btn btn-sm btn-warning">Processing</b>
                                                <?php endif; ?>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo $invests->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About Hostonion End -->



    <script>
        (function($){
            $(window).on('resize',function(){
                var bodyHeight = $(window).height();
                $('#min-height-activity').css('min-height',parseInt(bodyHeight) - 450);
                console.log(bodyHeight)
            })
            var bodyHeight = $(window).height();
            $('#min-height-activity').css('min-height',parseInt(bodyHeight) - 450);
            console.log(bodyHeight)


        }(jQuery))
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>