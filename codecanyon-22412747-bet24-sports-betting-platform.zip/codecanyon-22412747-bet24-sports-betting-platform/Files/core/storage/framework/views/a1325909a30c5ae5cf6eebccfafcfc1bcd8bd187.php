

<?php $__env->startSection('content'); ?>
    <style type="text/css">
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
        }
    </style>

    <div class="bet-section" id="min-height-option">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <aside class="widget card widget--sidebar widget-standings">
                        <?php echo $__env->make('partials.event', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo show_add(1); ?>

                    </aside>
                </div>
                <div class="col-md-6">
                    <div class="panel custom-panel-bg panel-default widget-content panel-content" style="margin-bottom:15px;">
                        <div class="panel-heading">
                            <div class="betOption">
                                <h5><?php echo e($ques->question); ?> </h5>
                                <small><b><?php echo e($ques->match->name); ?></b></small>
                            </div>
                        </div>

                        <div class="panel-body bet-body">

                            <?php if($ques->match->src != null): ?>
                                <div class="rwo">
                                    <div class="col-md-12">
                                        <div class="videoWrapper">
                                            <?php echo $ques->match->src; ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>


                            <?php if($ques->end_time >= Carbon\Carbon::now()): ?>
                                <?php
                                    $now = Carbon\Carbon::now();
                                ?>
                                <?php if($ques->match->end_date > $now): ?>
                                    <div class="col-md-12">
                                        <button class="btn btn-block bs-callout bs-callout-warning  ">
                                            Bet will be expired in <span id="countTimer<?php echo e($ques->id); ?>"></span>
                                        </button>
                                    </div>
                                    <?php $__currentLoopData = $bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <?php if(Auth::user()): ?>
                                                <div class="bs-callout bs-callout-warning bet-option open_modal_for_bet"
                                                     data-toggle="modal" data-id="<?php echo e($data->id); ?>"
                                                     data-target="#myModal<?php echo e($data->id); ?>">
                                                    <b> <?php echo e($data->option_name); ?> <span class="pull-right"><?php echo e($data->ratio1); ?>

                                                            : <?php echo e($data->ratio2); ?> </span> </b>
                                                </div>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('login')); ?>">
                                                    <div class="bs-callout bs-callout-warning bet-option open_modal_for_bet">
                                                        <b> <?php echo e($data->option_name); ?> <span class="pull-right"><?php echo e($data->ratio1); ?>

                                                                : <?php echo e($data->ratio2); ?> </span> </b>
                                                    </div>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                        <!-- Modal for Edit button -->
                                        <div class="modal fade" id="myModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal"
                                                                aria-hidden="true">&times;
                                                        </button>
                                                        <h4 class="modal-title">Bet Option </h4>
                                                    </div>
                                                    <form action="<?php echo e(route('betByUser')); ?>" method="post">
                                                        <?php echo e(csrf_field()); ?>

                                                        <div class="modal-body">
                                                            <div class="form-group">
                                                                <?php if(Auth::user()): ?>
                                                                    <input type="hidden" value="<?php echo e(Auth::user()->id); ?>"
                                                                           name="user_id">
                                                                <?php endif; ?>
                                                                <label><strong>Invest Amount </strong></label>
                                                                <input class="form-control ronnie_id" type="hidden"
                                                                       value="<?php echo e($data->id); ?>" name="betoption_id">

                                                                <input class="form-control ronnie_id" type="hidden"
                                                                       value="<?php echo e($ques->match->id); ?>" name="match_id">

                                                                <input class="form-control ratio1" type="hidden"
                                                                       value="<?php echo e($data->ratio1); ?>">
                                                                <input class="form-control ratio2" type="hidden"
                                                                       value="<?php echo e($data->ratio2); ?>">
                                                                <input type="text"
                                                                       class="form-control input-lg ronnie_bet get_amount_for_ratio"
                                                                       name="invest_amount" placeholder=" Amount"
                                                                       required>
                                                                <code>Minimum Bet
                                                                    Amount <?php echo e($data->min_amo); ?> <?php echo e($basic->currency); ?></code>
                                                            </div>
                                                            <div class="form-group">
                                                                <label><strong>Return Amount</strong> (If You
                                                                    win)</label>
                                                                <input class="form-control input-lg ronnie_ratio"
                                                                       name="return_amount" placeholder="Return Amount" readonly>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-danger"
                                                                    data-dismiss="modal">No
                                                            </button>
                                                            <button type="submit" class="btn btn-success">Send</button>
                                                        </div>

                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>

                                    <?php
                                        $dd = App\Match::find($ques->match->id);
                                       $dd->status = 2;
                                       $dd->save();
                                    ?>
                                    <div class="col-md-12">
                                        <button class="btn btn-block bs-callout bs-callout-warning  ">
                                            Already Expired !!
                                        </button>
                                    </div>

                                <?php endif; ?>

                            <?php else: ?>
                                    <br>
                                <h5 class="red text-center">Bet  Time out</h5>
                            <?php endif; ?>
                        </div>
                    </div>

                    <br>
                    <?php echo show_add(2); ?>

                </div>

                <aside>
                    <div class="col-md-3">
                        <?php echo show_add(3); ?>


                    </div>
                </aside>

            </div>
        </div>

    </div>


    <script>
        // Set the date we're counting down to
        var countDownDate = new Date("<?php echo e($ques->end_time); ?>").getTime();

        // Update the count down every 1 second
        var x = setInterval(function () {

            // Get todays date and time
            var now = new Date().getTime();

            // Find the distance between now an the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Output the result in an element with id="demo"
            document.getElementById("countTimer<?php echo e($ques->id); ?>").innerHTML = days + " Day " + hours + "h "
                + minutes + "m " + seconds + "s ";

            // If the count down is over, write some text
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("countTimer<?php echo e($ques->id); ?>").innerHTML = "EXPIRED";
            }
        }, 1000);
    </script>

    <script>
        $(document).ready(function () {
            $(document).on('keyup', '.get_amount_for_ratio', function () {
                var $selector = $(this);
                setTimeout(function () {
                    let amount = $selector.val();
                    let ratio1 = $selector.siblings('.ratio1').val();
                    let ratio2 = $selector.siblings('.ratio2').val();
                    // console.log({'raton1':ratio1,'ratio2':ratio2,'amount':amount})
                    let finalRation = parseFloat((amount * ratio2) / ratio1).toFixed(2);
                    $selector.parent().parent().children().children('.ronnie_ratio').val(finalRation);
                }, 500);
            });
        });
    </script>

    <script>
        (function ($) {
            $(window).on('resize', function () {
                var bodyHeight = $(window).height();
                $('#min-height-option').css('min-height', parseInt(bodyHeight) - 450);
                console.log(bodyHeight)
            })
            var bodyHeight = $(window).height();
            $('#min-height-option').css('min-height', parseInt(bodyHeight) - 450);
            console.log(bodyHeight)


        }(jQuery))
    </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>